<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function __construct()
    {
        parent::__construct();

        $this->load->model('common_model');
		$SES_MESSAGE = $_SESSION['N_SES_MSG_DATA'] = '';
    }

	public function index()
	{
		$data['departments']=$this->common_model->getData('tbl_employees');
		$this->load->view('index',$data);
	}
	public function importdata()
	{ 
		if(isset($_POST["submit"]))
		{
			$file = $_FILES['file']['tmp_name'];
			if(!empty($file)){	
				$handlerow= fopen($file, "r");
				$handle = fopen($file, "r");
				$c = 0;//
				$row=0;
				$errorlist=array();

				while(($filesoprow = fgetcsv($handlerow, 1000, ",")) !== false)
				{
					
					if($row>0)
					{
						
						if($filesoprow[0]==""){
							$errorlist[$row]="Employee code missing, ";
						}else if($filesoprow[1]==""){
							$errorlist[$row]="Employee Name missing, ";
						}
						else if($filesoprow[2]==""){
							$errorlist[$row]="Employee Department missing, ";
						}
						else if($filesoprow[3]==""){
							$errorlist[$row]="Employee Dob missing,";
						}
						else if($filesoprow[4]==""){
							$errorlist[$row]="Date of Join missing,";
						}
						if($row<5 && $row>20){
							$errorlist[$row]="File not uploded!!excel  minimun 5 rows And maximum 50 rows";
						  }
						  
					}
					$row++;
					
				}
				// echo "<pre/>";
				// print_r($errorlist);
				if(empty($errorlist)){
					if($row>5 && $row<20){
							while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
							{
								$data=array(
									'emp_code'=>$filesop[0],
									'emp_name'=>$filesop[1],
									'emp_dept'=>$filesop[2],
									'emp_dob'=>$filesop[3],
									'emp_join'=>$filesop[4]
								);
								if($c<>0){					/* SKIP THE FIRST ROW */
									$this->common_model->saverecords($data);
								}
								$c = $c + 1;
							}
							$this->session->set_flashdata('message', 'sucessfully import data !');
							// echo "sucessfully import data !";
					}$this->session->set_flashdata('errormessage',array('File not uploded!!excel  minimun 5 rows And maximum 50 rows'));
				}else{
					$this->session->set_flashdata('errormessage',$errorlist);
				}
				
			}	
			redirect(site_url() . '/home');
		}
	}
	
}
