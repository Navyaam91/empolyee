<?php 
class Common_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        
    }

    public function getData($table){
        $this->db->select("*");
        $this->db->from($table);
        $result = $this->db->get();	
		return $result->result_array();
    }
    function saverecords($data)
	{
		$this->db->insert('tbl_employees', $data);
	}
    public function existing_empcode(){
        $this->db->select('emp_code');
        $this->db->from('tbl_employees');
        $result = $this->db->get();	
		return $result->row_array();
    }
    

}
?>