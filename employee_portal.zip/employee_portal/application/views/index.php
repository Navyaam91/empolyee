<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Employee portal</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="<?=base_url(); ?>assets/css/styles.css" rel="stylesheet" />
    </head>
    <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container px-lg-5">
                <a class="navbar-brand" href="#!">Employee portal</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="<?=base_url();?>">Home</a></li>
                      
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Header-->
        <header class="py-5">
            <div class="container px-lg-5">
                <div class="p-4 p-lg-5 bg-light rounded-3 text-center">
                    <div class="m-4 m-lg-5">
                        <h1 class="display-5 fw-bold">Employees</h1>
                       
                    </div>
                </div>
            </div>
        </header>
        <!-- Page Content-->
        <section class="pt-4">
            
            <div class="container px-lg-5">
            <?php if($this->session->flashdata('message')) { ?>
            <div class="alert alert-info" id="success">
            <p><?php echo $this->session->flashdata('message');?></p>
            </div>
            <?php }  
            else if($this->session->flashdata('errormessage')) {
            ?>
            <div class="alert alert-danger" id="error">
            <p><?php 
            foreach($_SESSION['errormessage'] as $err){
                echo $err;
            }?></p>
            </div>
            <?php } ?>
            <?php //echo $_SESSION['N_SES_MSG_DATA'] ; ?>
            <form enctype="multipart/form-data" method="post" role="form" action="<?=site_url()?>/home/importdata">
            <div class="form-group">
            <label for="exampleInputFile">File Upload</label>
            <input type="file" name="file" id="file" size="150">
            <p class="help-block">Only Excel/CSV File Import.</p>
            </div>
            <button type="submit" class="btn btn-primary" name="submit" value="submit">Upload</button>
            </form>
         
            



                <!-- Page Features-->
                <table class="table table-striped">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Emp code</th>
                        <th scope="col">Name</th>
                        <th scope="col">Department</th> 
                        <th scope="col">Dob</th>
                        <th scope="col">Joining Date</th>                         
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $i=1;
                        foreach($departments as $department){ ?>
                        <tr>
                        <th scope="row"><?=$i?></th>
                        <td><?php echo $department['emp_code']; ?></td>
                        <td><?php echo $department['emp_name']; ?></td>
                        <td><?php echo $department['emp_dept']; ?></td>
                        <td><?php echo $department['emp_dob']; ?></td>
                        <td><?php echo $department['emp_join']; ?></td>
                       
                        </tr>
                        <?php
                            $i++;
                            } ?>
                        
                    </tbody>
                    </table>
            </div>
        </section>
        <!-- Footer-->
        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white"</p></div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <!-- <script src="js/scripts.js"></script> -->
        <script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
        <script>
            if($( "#success" ).html()!=""){
                $( "#success" ).fadeOut( 3000 );
                // window.location.href = '<?php echo site_url(); ?>/home';

            }
            if($( "#error" ).html()!=""){
                $( "#error" ).fadeOut( 3000 );
            }
        </script>
    </body>
</html>
